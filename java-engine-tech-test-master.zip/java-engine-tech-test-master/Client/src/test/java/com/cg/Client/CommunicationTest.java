package com.cg.Client;

import com.cg.Client.Client;
import org.junit.Test;

public class CommunicationTest { 

    @Test
    public void testHelloRequestCorrect() throws Exception {
        String res = Client.postRequest("Hello");
        assert (res.equals("Hello stranger!"));
    }

    @Test
    public void testHelloRequestIncorrect() throws Exception {
        String res = Client.postRequest("hello");
        assert (res.equals("Error! No or invalid request name specified! (hello)"));
    }

    @Test
    public void testChanceForFourtyPerRequest() throws Exception {
        String res = Client.postRequest("40.00%");
        assert (res.equals("�0.00"));
    }
    
    @Test
    public void testChanceForThirtyPerRequest() throws Exception {
        String res = Client.postRequest("30.00%");
        assert (res.equals("�1.00"));
    }
    
    @Test
    public void testChanceForTwentyPerRequest() throws Exception {
        String res = Client.postRequest("20.00%");
        assert (res.equals("�2.00"));
    }

    @Test
    public void testChanceForTenPerRequest() throws Exception {
        String res = Client.postRequest("10.00%");
        assert (res.equals("�3.00"));
    }
    
    //add more tests here to validate your work
}
