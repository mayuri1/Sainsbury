Java developer technical test Sainsbury's - March 2020

The Test 

Purpose of this test is to build a Java console application that scrapes the Sainsbury’s grocery site’s - Berries, Cherries, Currants page and returns a JSON array of all the products on the page.

Requirements
 * Git
 * Java 8 (JDK 8).
 * Apache Maven 3.5.4.
 * Jsoup - for scraping webpages.

Run the project as a Java Application in the IDE, with or without arguments.If no arguments are specified, the user will be prompted for input in the console.
You can simply hit ENTER and the application will run with the default link provided:

The link to use is: https://jsainsburyplc.github.io/serverside-test/site/www.sainsburys.co.uk/webapp/wcs/stores/servlet/gb/groceries/berries-cherries-currants6039.html
