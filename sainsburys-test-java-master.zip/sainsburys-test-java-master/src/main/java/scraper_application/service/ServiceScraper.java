package scraper_application.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import scraper_application.model.JsonModel;
import scraper_application.model.ScrapedModelObject;
import scraper_application.model.ScrapedModelObjectTotal;

@Service
public class ServiceScraper
{
	private static final String DOMAIN_URL = "https://jsainsburyplc.github.io/serverside-test/site/www.sainsburys.co.uk/";
	private static final String LINK_SANITISING_PATTERN = "(../)+";
	
	private static final String OBJECT_SELECTOR = "ul.productLister a";
	private static final String OBJECT_HREF_SELECTOR = "href";
	
	public JsonModel getJsonModelFromUri(URI webpageUri) throws MalformedURLException, IOException
	{
		Document webpage = Jsoup.connect(webpageUri.toURL().toString()).get();
		
		/*Document webpage = Jsoup //
	               .connect("http://google.com/") //
	               .proxy("localhost", 8080) // sets a HTTP proxy
	               .userAgent("Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2") //
	               .header("Content-Language", "en-US") //
	               .get();*/
		/*Document webpage = Jsoup.connect(webpageUri.toURL().toString())
        .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")             
        .get();*/
		
		Set<String> allScrapedObjectsLinks = webpage.select(OBJECT_SELECTOR).stream()
			.map(elem -> elem.attr(OBJECT_HREF_SELECTOR))
			.map(elem -> DOMAIN_URL + elem.replaceFirst(LINK_SANITISING_PATTERN, ""))
			.filter(elem -> elem.contains("berries-cherries-currants"))
			.collect(Collectors.toSet());
		
		// -- DEBUG
		System.out.println("Found the following links:");
		
		for (String link : allScrapedObjectsLinks)
		{
			System.out.println(link);
		}
	
		// call the method to parse all found links and return the JsonModel object	
		return parseAllScrapedObjectsLinks(allScrapedObjectsLinks);
	}
	
	private JsonModel parseAllScrapedObjectsLinks(final Set<String> allScrapedObjectsLinks) throws IOException
	{
		JsonModel jsonObject = new JsonModel();
		List<ScrapedModelObject> scrapedObjects = new ArrayList<>(allScrapedObjectsLinks.size());
		List<ScrapedModelObjectTotal> scrapedObjectsTotal = new ArrayList<>(allScrapedObjectsLinks.size());
		Double total = new Double(0);
		Double vat = new Double(0);
		
		for (String link : allScrapedObjectsLinks)
		{		
			Document productPage = Jsoup.connect(link).get();
			ScrapedModelObject scrapedObject= new ScrapedModelObject();
			scrapedObject.setTitle(ScraperHelperService.getScrapedObjectTitle(link, productPage));
			if(ScraperHelperService.getScrapedObjectKcal(link, productPage)!=null)
			scrapedObject.setKcalPerHundredGrams(ScraperHelperService.getScrapedObjectKcal(link, productPage).replace("kcal", ""));
			scrapedObject.setUnitPrice(ScraperHelperService.getScrapedObjectUnitPrice(link, productPage));
			scrapedObject.setDescription(ScraperHelperService.getScrapedObjectDescription(link, productPage));
				
			scrapedObjects.add(scrapedObject);
			if (scrapedObject.getUnitPrice() != null)
			{
				total += scrapedObject.getUnitPrice();// calculate gross
			}
			
		}
		// Calculate vat
		vat = total/1.2;
		
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		ScrapedModelObjectTotal scrapedObjectTotal = new ScrapedModelObjectTotal();
		scrapedObjectTotal.setVat(df.format(total-vat));
		scrapedObjectTotal.setGross(total);
		scrapedObjectsTotal.add(scrapedObjectTotal);
		
		jsonObject.setResults(scrapedObjects);
		jsonObject.setTotal(scrapedObjectsTotal);
		
		return jsonObject;
	}
}
