package scraper_application.controllers;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import scraper_application.model.JsonModel;
import scraper_application.service.ServiceScraper;

@Component
public class MainController
{
	@Autowired
	private ServiceScraper serviceScraper;
	
    public void scrapeUsingUri(final URI uriInput)
    {
    	System.out.println("Scraping webpage from link : " + uriInput + "\n");
    	
    	try
    	{
    		
    		JsonModel jsonObject = serviceScraper.getJsonModelFromUri(uriInput);
    	
    		System.out.println("\nThe JSON object :\n");
    		
    		ObjectMapper objectMapper = new ObjectMapper();
    		
    		System.out.println(objectMapper.writeValueAsString(jsonObject));
    		
    		System.out.println("\nScraping Finished.\n");
    	}
    	catch (MalformedURLException e)
    	{
    		e.printStackTrace();
    	}
    	catch (IOException e)
    	{
    		e.printStackTrace();
    	}
    }
}
