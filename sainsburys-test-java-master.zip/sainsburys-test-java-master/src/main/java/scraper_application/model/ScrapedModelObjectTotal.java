package scraper_application.model;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder(value = {ScrapedModelObjectTotal.GROSS, ScrapedModelObjectTotal.VAT})
@Component
public class ScrapedModelObjectTotal
{
    protected static final String GROSS = "gross";
    protected static final String VAT = "vat";
   
	@NotNull
	@JsonProperty(GROSS)
	private Double gross;
	
	@NotNull
	@JsonProperty(VAT)
	private String vat;
	
	public Double getGross() {
		return gross;
	}
	public void setGross(Double gross) {
		this.gross = gross;
	}
	public @NotNull String getVat() {
		return vat;
	}
	public void setVat(String string) {
		this.vat = string;
	}
}
	
