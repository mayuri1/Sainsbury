package scraper_application.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder(value = { JsonModel.RESULTS, JsonModel.TOTAL })
public class JsonModel
{
	protected static final String RESULTS = "results";
    protected static final String TOTAL = "total";
    
    @NotNull
    @NotEmpty
    @JsonProperty(RESULTS)
    private List<ScrapedModelObject> results;

    /** The total. */
    @NotNull
    @JsonProperty(TOTAL)
    private List<ScrapedModelObjectTotal> total;
    
	public List<ScrapedModelObject> getResults() {
		return results;
	}

	public void setResults(List<ScrapedModelObject> results) {
		this.results = results;
	}

	public List<ScrapedModelObjectTotal> getTotal() {
		return total;
	}

	public void setTotal(List<ScrapedModelObjectTotal> scrapedObjectsTotal) {
		this.total = scrapedObjectsTotal;
	}
	
}
