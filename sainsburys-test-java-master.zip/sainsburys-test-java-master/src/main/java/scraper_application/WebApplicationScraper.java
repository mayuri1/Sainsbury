
package scraper_application;

import java.io.IOException;
import java.net.URI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.util.UriComponentsBuilder;

import scraper_application.controllers.MainController;

@SpringBootApplication
public class WebApplicationScraper
{   
    // Default URL link
	//private static final String DEFAULT_URL = "http://google.com";
    private static final String DEFAULT_URL = "https://jsainsburyplc.github.io/serverside-test/site/"
    		+ "www.sainsburys.co.uk/webapp/wcs/stores/servlet/gb/groceries/berries-cherries-currants6039.html";
    
    @Autowired
    private MainController mainController;
	
	public static void main(String[] args) throws IOException
	{
		
		final ConfigurableApplicationContext context = SpringApplication.run(WebApplicationScraper.class);

        final WebApplicationScraper webApp = context.getBean(WebApplicationScraper.class);

        webApp.scrape(args);
        
        // close the application
        SpringApplication.exit(context);
	}
		
	private void scrape(final String[] args) throws IOException
	{
			mainController.scrapeUsingUri(getUriFromInput(DEFAULT_URL));
	}
	
	private URI getUriFromInput(String input)
	{
		return UriComponentsBuilder.fromHttpUrl(input).build().toUri();
	}
	
}
